const { PLANNING_APPROVE_ROLES, AUDIT_PROPOSAL_CREATE_ROLES } = require("../config/roles");
const { classifyRisk } = require("../config/riskRules");

const dashboardCopy = {
  SUPER_ADMIN: {
    title: "Control ejecutivo del portafolio",
    description: "Riesgos, decisiones y ejecución de todas las auditorías.",
    scopeLabel: "Portafolio completo"
  },
  DIRECTOR: {
    title: "Decisiones del portafolio",
    description: "Prioriza propuestas y da seguimiento a la ejecución.",
    scopeLabel: "Portafolio completo"
  },
  GERENTE: {
    title: "Seguimiento de planeación",
    description: "Revisa propuestas abiertas y el avance del plan anual.",
    scopeLabel: "Planeación"
  },
  AUDITOR: {
    title: "Mis auditorías asignadas",
    description: "Consulta tu carga, prioridades y auditorías en curso.",
    scopeLabel: "Solo mis asignaciones"
  },
  JEFATURA: {
    title: "Seguimiento del portafolio",
    description: "Propón auditorías y consulta las prioridades del portafolio.",
    scopeLabel: "Planeación y seguimiento"
  }
};

const getDashboardForUser = (user, proposals, findings = []) => {
  const isAuditor = user.role === "AUDITOR";
  const visibleProposals = isAuditor
    ? proposals.filter((proposal) => proposal.responsibleId === user.id)
    : proposals;
  const activeAudits = visibleProposals.filter((proposal) => proposal.status === "ACTIVE");
  const visibleAuditIds = new Set(visibleProposals.map((proposal) => proposal.id));
  const openFindings = findings.filter((finding) => finding.status === "OPEN" && visibleAuditIds.has(finding.auditId));
  const executingAudits = visibleProposals.filter((proposal) => ["ACTIVE", "CLOSED"].includes(proposal.status));
  const statusCounts = ["OPEN", "APPROVED", "ACTIVE", "CLOSED", "REJECTED"].map((status) => ({
    status,
    count: visibleProposals.filter((proposal) => proposal.status === status).length
  }));
  const riskMatrix = [1, 2, 3].map((likelihood) => [1, 2, 3].map((impact) => {
    const score = likelihood * impact;
    return {
      likelihood,
      impact,
      risk: classifyRisk(score),
      count: activeAudits.filter((audit) => (audit.likelihood ?? 2) === likelihood && (audit.impact ?? 2) === impact).length
    };
  }));
  let pendingItems;
  if (PLANNING_APPROVE_ROLES.includes(user.role)) {
    pendingItems = visibleProposals.filter((proposal) => proposal.status === "OPEN");
  } else if (user.role === "AUDITOR") {
    pendingItems = visibleProposals.filter((proposal) => ["OPEN", "APPROVED", "ACTIVE"].includes(proposal.status));
  } else if (user.role === "JEFATURA") {
    pendingItems = visibleProposals.filter((proposal) => proposal.status === "OPEN" && proposal.createdBy?.id === user.id);
  } else if (AUDIT_PROPOSAL_CREATE_ROLES.includes(user.role)) {
    pendingItems = visibleProposals.filter((proposal) => proposal.status === "OPEN");
  } else {
    pendingItems = visibleProposals.filter((proposal) => proposal.status === "ACTIVE");
  }

  const heading = dashboardCopy[user.role] || dashboardCopy.JEFATURA;
  return {
    role: user.role,
    ...heading,
    metrics: {
      total: visibleProposals.length,
      pending: visibleProposals.filter((proposal) => proposal.status === "OPEN").length,
      active: activeAudits.length,
      openFindings: openFindings.length,
      highRisk: visibleProposals.filter((proposal) => proposal.risk === "Alto").length,
      averageProgress: executingAudits.length
        ? Math.round(executingAudits.reduce((total, proposal) => total + (proposal.progress ?? 0), 0) / executingAudits.length)
        : 0
    },
    statusCounts,
    riskMatrix,
    pendingItems: pendingItems.slice(0, 8).map((proposal) => ({
      id: proposal.id,
      title: proposal.title,
      area: proposal.area,
      status: proposal.status,
      risk: proposal.risk,
      quarter: proposal.quarter,
      year: proposal.year,
      progress: proposal.progress ?? 0
    })),
    permissions: {
      canCreate: AUDIT_PROPOSAL_CREATE_ROLES.includes(user.role),
      canApprove: PLANNING_APPROVE_ROLES.includes(user.role),
      canManageExecution: PLANNING_APPROVE_ROLES.includes(user.role)
    }
  };
};

module.exports = { getDashboardForUser };
