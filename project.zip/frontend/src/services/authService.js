const API_URL = "/api/auth";

export const verify2FA = async (tempToken, code) => {
  const response = await fetch(`${API_URL}/verify-2fa`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tempToken, code })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Código incorrecto");
  return data;
};

export const loginUser = async (username, password) => {
  const response = await fetch(`${API_URL}/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      username,
      password
    })
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || "Error al iniciar sesión");
  }

  return data;
};

// HU-01: registro propio. La cuenta queda pendiente de aprobación.
export const registerUser = async ({ name, email, password }) => {
  const response = await fetch(`${API_URL}/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, email, password })
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || "No se pudo enviar la solicitud.");
  }

  return data;
};
